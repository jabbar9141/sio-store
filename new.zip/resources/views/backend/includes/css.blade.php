<!-- loader-->
<link href="{{asset('backend_assets')}}/css/pace.min.css" rel="stylesheet" />
<script src="{{asset('backend_assets')}}/js/pace.min.js"></script>
<!-- Bootstrap CSS -->
<link href="{{asset('backend_assets')}}/css/bootstrap.min.css" rel="stylesheet">
<link href="{{asset('backend_assets')}}/css/app.css" rel="stylesheet">
<link href="{{asset('backend_assets')}}/css/icons.css" rel="stylesheet">
<!-- Theme Style CSS -->
<link rel="stylesheet" href="{{asset('backend_assets')}}/css/dark-theme.css" />
<link rel="stylesheet" href="{{asset('backend_assets')}}/css/semi-dark.css" />
<link rel="stylesheet" href="{{asset('backend_assets')}}/css/header-colors.css" />
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
  integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
  crossorigin="anonymous"
  referrerpolicy="no-referrer"
/>
