<!--plugins-->
<link href="{{asset('backend_assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')}}" rel="stylesheet"/>
<link href="{{asset('backend_assets/plugins/simplebar/css/simplebar.css')}}" rel="stylesheet" />
<link href="{{asset('backend_assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css')}}" rel="stylesheet" />
<link href="{{asset('backend_assets/plugins/metismenu/css/metisMenu.min.css')}}" rel="stylesheet" />
