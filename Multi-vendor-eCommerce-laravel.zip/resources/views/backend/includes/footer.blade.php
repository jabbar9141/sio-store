<footer class="page-footer">
   <p class="mb-0">Siostore © {{date("Y")}}. All right reserved.</p>
</footer>
