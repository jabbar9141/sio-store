@extends('user.layout.app')

@section('page_name', $product->product_name)

@section('content')

    <style>
        .cart-submit {

            max-width: 200px;
            padding: 10px;

            width: 100%;

        }

        .cart-submit:hover,
        .cart-submit:not(:disabled):not(.disabled):active,
        .cart-submit:focus {
            background-color: #232f3e;
            border-color: #232f3e;
            box-shadow: none !important;
        }

        .product-nav-tabs {

            justify-content: center;

            gap: 20px;

            border-bottom: none;

        }



        .product-nav-tabs a.nav-item.nav-link.text-dark {

            background-color: #dee2e6;

        }





        .product-nav-tabs .nav-link.active {

            background-color: #1575b8 !important;

            color: #ffffff !important;

        }





        .quantity-btn {

            border: 1px solid #1476b8 !important;

        }



        .quantity-btn button {

            padding: 10px 15px;

        }



        .quantity-btn .form-control {

            padding-block: 11px;

            height: 100%;

        }



        .quantity-btn button:hover,

        .quantity-btn button:focus {

            background-color: #232f3e;

            border-color: #232f3e;

            box-shadow: none;

        }









        .quantity-btn .btn-primary:not(:disabled):not(.disabled):active {

            background-color: #232f3e;

            border-color: #232f3e;

            box-shadow: none;

        }



        .social-icon-grp i {

            background-color: #232f3e;

            color: #ffffff;

            height: 30px;

            width: 30px;

            display: flex;

            justify-content: center;

            align-items: center;



        }

        .related-img {
            height: 220px !important;
            object-fit: cover;
        }

        /*.productimg{*/

        /*    max-height: 300px !important;*/

        /*}*/



        @media screen and (max-width: 700px) {

            .disflexx {

                display: flex !important;

                flex-direction: column;

                gap: 10px;

            }

        }





            {}
    </style>









    <!-- Breadcrumb Start -->

    <div class="container-fluid px-0">

        <div class="row">

            <div class="col-12">

                <nav class="breadcrumb bg-light mb-30">

                    <a class="breadcrumb-item text-dark" href="{{ url('/') }}">Home</a>

                    <a class="breadcrumb-item text-dark" href="#">Shop</a>

                    <span class="breadcrumb-item active">{{ $product->product_name }}</span>

                </nav>

            </div>

        </div>

    </div>

    <!-- Breadcrumb End -->





    <!-- Shop Detail Start -->

    <div class="container-fluid pb-5">

        <div class="row px-xl-5">

            <div class="col-lg-5 mb-30">

                <div id="product-carousel" class="carousel slide h-100" data-ride="carousel">

                    <!-- Carousel Inner -->

                    <div class="carousel-inner bg-light h-100">

                        <!-- Carousel Items -->

                        @if ($product->images)

                            @php

                                $r = 0;

                            @endphp

                            @foreach ($product->images as $image)
                                <div class="carousel-item h-100 {{ $r == 0 ? 'active' : '' }}">

                                    <div class="productimg h-100">

                                        <img class="w-100 h-100" src="/uploads/images/product/{{ $image->product_image }}"
                                            alt="{{ $product->product_name }}">

                                    </div>

                                    <!--<img src="https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?cs=srgb&dl=pexels-madebymath-90946.jpg&fm=jpg" alt="" class="w-100 h-100">-->

                                </div>

                                @php

                                    $r++;

                                @endphp
                            @endforeach

                        @endif

                    </div>



                    <!-- Carousel Controls -->

                    <a class="carousel-control-prev" href="#product-carousel" data-slide="prev">

                        <i class="fa fa-2x fa-angle-left text-dark"></i>

                    </a>

                    <a class="carousel-control-next" href="#product-carousel" data-slide="next">

                        <i class="fa fa-2x fa-angle-right text-dark"></i>

                    </a>

                </div>



                <!-- Fullscreen Modal -->

                <div class="modal fade" id="fullscreenModal" tabindex="-1" role="dialog"
                    aria-labelledby="fullscreenModalLabel" aria-hidden="true">

                    <div class="modal-dialog modal-dialog-centered modal-lg">

                        <div class="modal-content">

                            <div class="modal-body">

                                <img id="fullscreenImage" class="w-100 h-100" src="" alt="">

                            </div>

                        </div>

                    </div>

                </div>



            </div>



            <div class="col-lg-7 h-auto mb-30">

                <div class="h-100 bg-light p-30">

                    <form method="POST" action="{{ route('store.addItem') }}" id="addToCartForm">

                        @csrf

                        <h3>{{ $product->product_name }}</h3>

                        <input type="hidden" name="product_id" value="{{ $product->product_id }}">

                        <div class="d-flex mb-3">

                            @php

                                $max_stars = 5;

                                $rating_avg = $product->getProductReviewsAvg() ?? 0;

                                $rating_avg_rounded = round($rating_avg * 2) / 2; // Round the rating average to the nearest half

                            @endphp



                            <div class="text-primary mr-2">

                                @for ($i = 1; $i <= $max_stars; $i++)
                                    @if ($i <= $rating_avg_rounded)
                                        <i class="fas fa-star"></i> <!-- Full star for whole numbers and half stars -->
                                    @elseif ($i - 0.5 == $rating_avg_rounded)
                                        <i class="fas fa-star-half-alt"></i> <!-- Half star -->
                                    @else
                                        <i class="fas fa-star text-secondary"></i> <!-- Gray star for unrated stars -->
                                    @endif
                                @endfor

                            </div>

                            <small class="pt-1">({{ round($rating_avg, 1) }} Stars from

                                {{ $product->getProductReviewsCount() }}

                                Reviews)</small>

                        </div>

                        <h3 class="font-weight-semi-bold mb-4">&euro; {{ $product->product_price }}</h3>

                        <div>

                            <h6>Shipping fees</h6>

                            @php

                                $shipping_cost = ((array) json_decode($shipping_cost));

                            @endphp

                            @if ($shipping_cost)

                                @foreach ($shipping_cost as $company => $cost)
                                    @if (!empty($cost))
                                        <p>

                                            <small>

                                                &euro; <b>{{ $cost }}</b> To ship to

                                                <b>{{ session('ship_to_str') }}</b>

                                                Via

                                                <b>{{ strtoupper($company) }}</b>

                                            </small>

                                        </p>
                                    @endif
                                @endforeach
                            @else
                                Shipping Cost not avilable for your sellected location

                            @endif



                        </div>

                        <p class="mb-4">{{ $product->product_short_description }}</p>

                        <div class="mb-3">



                            @if ($product->product_colors)

                                @php

                                    $variations = json_decode($product->product_colors);

                                    $l = 0;

                                @endphp

                                @foreach ($variations as $variation)
                                    <div>

                                        <strong class="text-dark mr-3">{{ $variation->variation_name }}:</strong>

                                        @php

                                            $l = 0;

                                        @endphp

                                        @foreach (explode(',', $variation->variation_values) as $value)
                                            <div class="custom-control custom-radio custom-control-inline">

                                                <input type="radio" class="custom-control-input" id="{{ $value }}"
                                                    name="variations[{{ $variation->variation_name }}]"
                                                    value="{{ $value }}" {{ $l == 0 ? 'checked' : '' }}>

                                                <label class="custom-control-label"
                                                    for="{{ $value }}">{{ $value }}</label>

                                            </div>

                                            @php

                                                $l++;

                                            @endphp
                                        @endforeach



                                    </div>

                                    <br>
                                @endforeach

                            @endif



                        </div>

                        <div class="d-flex align-items-center disflexx mb-4 pt-2">

                            <div class="input-group quantity mr-3 quantity-btn" style="width: 130px;">

                                <div class="input-group-btn">

                                    <button class="btn btn-primary btn-minus" type="button">

                                        <i class="fa fa-minus"></i>

                                    </button>

                                </div>

                                <input type="text" class="form-control bg-secondary border-0 text-center" value="1"
                                    min="1" name="qty" readonly>

                                <div class="input-group-btn">

                                    <button class="btn btn-primary btn-plus" type="button">

                                        <i class="fa fa-plus"></i>

                                    </button>

                                </div>

                            </div>

                            <button class="btn btn-primary px-3 cart-submit" type="submit"><i
                                    class="fa fa-shopping-cart mr-1"></i> Add

                                To

                                Cart</button>

                            @auth

                                @php

                                    $t = \App\MyHelpers::userLikesItem($product->product_id);

                                @endphp

                                @if (!$t)
                                    <button class="btn btn-primary mx-3" type="button"
                                        onclick="likeItem('{{ $product->product_id }}')"><i class="fa fa-heart mr-1"></i> Add

                                        To

                                        Wishlist</button>
                                @else
                                    <button class="btn btn-primary mx-3" type="button"
                                        onclick="likeItem('{{ $product->product_id }}')"><i class="fa fa-heart mr-1"></i>

                                        Remove From

                                        Wishlist</button>
                                @endif

                            @endauth



                        </div>

                    </form>

                    <form id="like-item-{{ $product->product_id }}" action="{{ route('wishlist.store') }}" method="POST"
                        style="display: none;">

                        @csrf

                        <input type="hidden" name="product_id" value="{{ $product->product_id }}">

                    </form>

                    <div class="d-flex pt-2">

                        <strong class="text-dark mr-2">Share on:</strong>

                        <div class="d-inline-flex social-icon-grp">

                            <a class="text-dark px-2" href="">

                                <i class="fab fa-facebook-f"></i>

                            </a>

                            <a class="text-dark px-2" href="">

                                <i class="fab fa-twitter"></i>

                            </a>

                            <a class="text-dark px-2" href="">

                                <i class="fab fa-linkedin-in"></i>

                            </a>

                            <a class="text-dark px-2" href="">

                                <i class="fab fa-pinterest"></i>

                            </a>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="row px-xl-5">

            <div class="col">

                <div class="bg-light p-30">

                    <div class="nav nav-tabs mb-4 product-nav-tabs">

                        <a class="nav-item nav-link text-dark active" data-toggle="tab"
                            href="#tab-pane-1">Description</a>

                        {{-- <a class="nav-item nav-link text-dark" data-toggle="tab" href="#tab-pane-2">Information</a> --}}

                        <a class="nav-item nav-link text-dark" data-toggle="tab" href="#tab-pane-3">Reviews

                            ({{ $product->getProductReviewsCount() }})</a>

                    </div>

                    <div class="tab-content">

                        <div class="tab-pane fade show active" id="tab-pane-1">

                            <h4 class="mb-3">Product Description</h4>

                            <p>{!! $product->product_long_description !!}</p>



                        </div>

                        {{-- <div class="tab-pane fade" id="tab-pane-2">

                            <h4 class="mb-3">Additional Information</h4>

                            <p></p>

                        </div> --}}

                        <div class="tab-pane fade" id="tab-pane-3">

                            <div class="row">

                                <div class="col-md-6">

                                    <h4 class="mb-4">{{ $product->getProductReviewsCount() }} review for

                                        {{ $product->product_name }}

                                    </h4>

                                    @foreach ($reviews as $r)
                                        <div class="media mb-4">

                                            <img src="{{ !empty($r->user->photo)
                                                ? url('uploads/images/profile/' . $r->user->photo)
                                                : url('uploads/images/user_default_image.png') }}"
                                                alt="Image" class="img-fluid mr-3 mt-1" style="width: 45px;">

                                            <div class="media-body">

                                                <h6>{{ '@' . $r->user->username }}<small> -

                                                        <i>{{ $r->created_at }}</i></small></h6>

                                                @php

                                                    $max_stars = 5;

                                                    $rating_avg = $r->rating;

                                                    $rating_avg_rounded = round($rating_avg * 2) / 2; // Round the rating average to the nearest half

                                                @endphp



                                                <div class="text-primary mr-2">

                                                    @for ($i = 1; $i <= $max_stars; $i++)
                                                        @if ($i <= $rating_avg_rounded)
                                                            <i class="fas fa-star"></i>

                                                            <!-- Full star for whole numbers and half stars -->
                                                        @elseif ($i - 0.5 == $rating_avg_rounded)
                                                            <i class="fas fa-star-half-alt"></i> <!-- Half star -->
                                                        @else
                                                            <i class="fas fa-star text-secondary"></i>

                                                            <!-- Gray star for unrated stars -->
                                                        @endif
                                                    @endfor

                                                </div>

                                                <p>{{ $r->comment }}</p>

                                            </div>

                                        </div>
                                    @endforeach

                                    {{ $reviews->links() }}

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="container-fluid pb-5">

        <div class="row px-xl-5">

            <div class="col">

                <div class="bg-light p-30">

                    <p>Seller Info:</p>

                    <div class="row">

                        <div class="col-sm-2">

                            <img src="{{ !empty($vendor->user->photo)
                                ? url('uploads/images/profile/' . $vendor->user->photo)
                                : url('uploads/images/user_default_image.png') }}"
                                alt="Image" class="img-fluid mr-3 mt-1" style="width: 80px;">

                        </div>

                        <div class="col-sm-10">

                            <h5>{{ $product->vendor->shop_name }} <a
                                    href="{{ route('store.showVendor', $product->vendor_id) }}">Visit Store</a></h5>

                        </div>

                    </div>



                    <hr>

                    <p>{!! $product->vendor->shop_description !!}</p>

                </div>

            </div>

        </div>

    </div>

    <!-- Shop Detail End -->







    <!-- Products Start -->

    <div class="container-fluid py-5">

        <h2 class="section-title position-relative text-uppercase mx-xl-5 mb-4"><span class="bg-secondary pr-3">You May
                Also Like</span></h2>

        <div class="row px-xl-5">

            <div class="col">

                <div class="owl-carousel related-carousel">

                    @if ($similar)
                        {{-- @php
                        dd($similar);
                        @endphp --}}

                        @foreach ($similar as $s)
                            <div class="card rounded px-2 h-100 d-flex flex-column">
                                <a href="{{ route('store.showProduct', $s->product_slug) }}" class="d-block h-100">

                                    <div class="related-img position-relative overflow-hidden">

                                        @if ($s->images && count($s->images) > 0)
                                            <img class="img-fluid w-100 img-thumbnail h-100"
                                                src="/uploads/images/product/{{ $s->images[0]->product_image }}"
                                                alt="{{ $s->product_name }}">
                                        @else
                                            <img class="img-fluid w-100 img-thumbnail h-100"
                                                src="{{ asset('uploads/images/product/bf51bb3bd5965bed168991794f01eafc.png') }}"
                                                alt="no image">
                                        @endif

                                        <div class="product-action">


                                        </div>

                                    </div>

                                    <div class="text-center py-4">

                                        <a class="h6 text-decoration-none text-blue-400"
                                            href="{{ route('store.showProduct', $s->product_slug) }}">

                                            @if (strlen($s->product_name) > 25)
                                                {{ substr($s->product_name, 0, 20) . '  ...  ' }}
                                            @else
                                                {{ $s->product_name }}
                                            @endif

                                        </a>

                                        <div class="d-flex align-items-center justify-content-center mt-2">

                                            <h5>&euro; {{ $s->product_price }}</h5>

                                            {{-- <h6 class="text-muted ml-2"><del>$123.00</del></h6> --}}

                                        </div>

                                        <div class="d-flex align-items-center justify-content-center mb-1">

                                            @php

                                                $max_stars = 5;

                                                $rating_avg = $s->getProductReviewsAvg() ?? 0;

                                                $rating_avg_rounded = round($rating_avg * 2) / 2; // Round the rating average to the nearest half

                                            @endphp



                                            <div class="text-primary mr-2">

                                                @for ($i = 1; $i <= $max_stars; $i++)
                                                    @if ($i <= $rating_avg_rounded)
                                                        <i class="fas fa-star"></i>

                                                        <!-- Full star for whole numbers and half stars -->
                                                    @elseif ($i - 0.5 == $rating_avg_rounded)
                                                        <i class="fas fa-star-half-alt"></i> <!-- Half star -->
                                                    @else
                                                        <i class="fas fa-star text-secondary"></i>

                                                        <!-- Gray star for unrated stars -->
                                                    @endif
                                                @endfor

                                            </div>

                                            <br>

                                            <div>

                                                <small>{{ round($rating_avg, 1) }} Stars,
                                                    {{ $s->getProductReviewsCount() }}

                                                    Reviews</small>

                                            </div>

                                        </div>

                                    </div>

                                </a>
                            </div>
                        @endforeach

                    @endif

                </div>

            </div>

        </div>

    </div>

    <style>
        .product-img-wrapper {

            height: 250px;

            /* Set a fixed height for the wrapper */

            overflow: hidden;

            /* Ensure any overflow is hidden */

        }



        .product-img-wrapper img {

            width: 100%;

            /* Allow the image to fill the width of the wrapper */

            height: auto;

            /* Maintain aspect ratio */

        }



        .product-image {

            height: 250px;

        }



        .text-blue-400 {

            color: #1575b8;

        }



        .text-blue-400:hover {

            color: lightblue;

        }



        .bg-blue {

            color: white;

            border-radius: 5px;

            background-color: #1575b8;

        }



        .bg-blue:hover {

            color: white;

            border-radius: 5px;

            background-color: lightblue;

        }
    </style>

    <!-- Products End -->



@endsection

@section('scripts')

    <script>
        $(document).ready(function() {

            // Handle click event on carousel items

            $('#product-carousel .carousel-item').on('click', function() {

                var imageUrl = $(this).find('img').attr('src');



                // Set the clicked image in the fullscreen modal

                $('#fullscreenImage').attr('src', imageUrl);



                // Show the fullscreen modal

                $('#fullscreenModal').modal('show');

            });

        });
    </script>

    <script>
        function likeItem(id) {

            event.preventDefault();

            let y = 1; //confirm('Are you sure you want to remove this item form your wishlist?');

            if (y) {

                document.getElementById('like-item-' + id).submit();

            }

        }
    </script>

@endsection
